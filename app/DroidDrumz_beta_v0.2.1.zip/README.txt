droidDrumz v0.2.1 beta
======================

**********************************************
* Open Source Android Drum Machine / Sampler *

* Copyright 2014 Rici Underwood              *
**********************************************

How to use
==========

It's pretty god damn simple to be honest...
Just bash away at the pads and them pads will make sound. 
If you hold down a pad, you can assign a different sound to it
from the 'Pad Assignment Menu'.
Click your devices menu button (to the right of the home button)
and there are currently 3 menu items, Pitch which is pretty much
self-explanatory, Themes which enables you to change to a snazzy
theme I have put together for you users out there and finally Presets, which holds a set of compiled drum kits you cn use.

TODO
====

* Record function
* Load / Save presets
* Load / Save settings (themes, etc...)

If there are any suggestions for features please do not hesitate to email 
myself the developer at the following...

c4po187@gmail.com

If i believe it to be a good idea and it fits with the spirit of the project,
one shall implement it, simple as that.

If you would like to contribute to the project, there are a few requirements...

* Java
* XML
* Photoshop/GIMP
* Audio Editing/Production
* Git 
* Be creative!

Remote Git Project > https://github.com/c4po187/droidDrumz.git
You will need to use 'git clone' to clone the above remote repository to your local repository 
you have set up, then you can crack on contributing and send pull requests to my account.


Finally, Enjoy the application! ;)